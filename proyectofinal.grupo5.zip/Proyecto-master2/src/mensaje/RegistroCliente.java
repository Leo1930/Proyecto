/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mensaje;

/**
 *
 * @author andre
 */
public class RegistroCliente {

    private String nombre;
    private String apellido;
    private String cedula;
    private String telefono;
    private String tipoSeguro;

    public RegistroCliente() {
    }
    {
        this.tipoSeguro="";
        this.cedula="";
    }

    public RegistroCliente(String nombre, String apellido, String cedula, String contacto,String tiposeguro) {

        this.nombre = nombre;
        this.apellido = apellido;
        this.cedula=cedula;
        this.telefono = contacto;
        this.tipoSeguro=tiposeguro;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getTipoSeguro() {
        return tipoSeguro;
    }

    public void setTipoSeguro(String tipoSeguro) {
        this.tipoSeguro = tipoSeguro;
    }

    @Override
    public String toString() {
        return "RegistroCliente{" + "nombre=" + nombre + ", apellido=" + apellido + ", cedula=" + cedula + ", telefono=" + telefono + ", tipoSeguro=" + tipoSeguro + '}';
    }
    
    

}
