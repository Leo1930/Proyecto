/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mensaje;

/**
 *
 * @author andre
 */
public class SeguroNormal {
    
    RegistroVehiculo c1;
    
    public double costoSeguro(){
        
       double costo=0;
       
       if("Baja".equals(c1.getGamaVehiculo())){
           costo=600;
       }
       if("Media".equals(c1.getGamaVehiculo())){
           costo=800;
       }
       if("Alta".equals(c1.getGamaVehiculo())){
           costo=1000;
       }
       if("Élite".equals(c1.getGamaVehiculo())){
           costo=1200;
       }
       return costo;
    }
}
