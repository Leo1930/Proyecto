/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mensaje;

/**
 *
 * @author andre
 */
public class SeguroPremium {
    
    RegistroVehiculo c1 = new RegistroVehiculo();
    
    public int costoSeguro(){
        
       int costo=0;
       
       if("Baja".equals(c1.getGamaVehiculo())){
           costo=700;
       }
       if("Media".equals(c1.getGamaVehiculo())){
           costo=900;
       }
       if("Alta".equals(c1.getGamaVehiculo())){
           costo=1200;
       }
       if("Élite".equals(c1.getGamaVehiculo())){
           costo=1500;
       }
       return costo;
    }
}
