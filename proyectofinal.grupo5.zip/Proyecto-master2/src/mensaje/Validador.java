/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mensaje;

/**
 *
 * @author kleber
 */
public class Validador {
    
    public static boolean validarPlaca(String placa){
        
        return placa.matches("[A-Z]{3}-[0-9]{3,4}$");
    }
    public static boolean verificarNombre(String nombre){
        return nombre.matches("^[a-zA-ZñÑ]+$");
    }
    public static boolean verificarApellido(String nombre){
        return nombre.matches("^[a-zA-ZñÑ]+$");
    }
    

}
