/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mensaje;

/**
 *
 * @author andre
 */
public class PagoSeguro {
    
    SeguroNormal sn = new SeguroNormal();
    SeguroPremium sp = new SeguroPremium();
    RegistroCliente c1 = new RegistroCliente();
   
    public double pagarSeguro(){
        
        double seguro = 0 ;
        if("Normal".equals(c1.getTipoSeguro())){
           seguro = sn.costoSeguro();}
        
        if("Premium".equals(c1.getTipoSeguro())){
            seguro = sp.costoSeguro();  }
        
        return seguro;
    }
}
