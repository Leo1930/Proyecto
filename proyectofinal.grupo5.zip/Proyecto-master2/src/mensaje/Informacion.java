/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mensaje;

/**
 *
 * @author andre
 */
public class Informacion {
    
    public String contrato(){
        return """
               Contrato
               Comparecen a suscribirse el presente contrato, por una parte y en calidad de AGENTE, el se\u00f1or Leonardo Andr\u00e9s Qhishpe C\u00e1rdenas,
               en su calidad de Gerente General de la aseguradora Llantas Alegres; y, por otra parte, y en calidad de ASEGURADO, el propietario de la p\u00f3liza, al tenor de las siguientes estipulaciones:
               PRIMERA. -Llantas alegres es una seguradora la cual procura la atenci\u00f3n amena hacia sus asegurados, a su vez procura la buena relaci\u00f3n con estos mismos para la aplicaci\u00f3n correcta de la p\u00f3liza.
               SEGUNDA. -Por su parte el asegurado declara ser una persona consciente del seguro que esta adquiriendo y esta satisfecha con la realizaci\u00f3n de este mismo en los casos especificados en el momento de la adquisici\u00f3n.
               TERCERA. \u2013 Como clausula adicional la aseguradora informa al asegurado que esta mismo podr\u00e1 reducir los beneficios en el caso que la p\u00f3liza no cubra un da\u00f1o de gran tama\u00f1o causado por el asegurado.
               CUARTA. \u2013 En caso de que se necesite el remplazo de una gran cantidad de piezas el asegurado deber\u00e1 dar una cierta cantidad en efectivo para la adquisici\u00f3n de estas.
               QUINTA. \u2013 El asegurado se compromete a pagar el valor de la p\u00f3liza de manera regular o en casos extremos con tres d\u00edas de retraso caso contrario esta ser\u00e1 cancelada por falta de pago prima.
               
               \u00bfAceptas las condiciones del contrato?""";
        
    }
    
    public String seguroNormal(){
        return """
               * Choque y/o volcadura.
               * Incendio y/o rayo.
               * Explosión.
               * Caida de edificios, aeronaves o partes de estas.
               * Impacto de proyectiles.
               * Deslizamientos de tierra.
               * Fenómenos de la naturaleza.
               * Pérdidas totales o parciales por daños.
               * Robo y/o hurto total o parcial.
               * Rotura de vidrios.
               * Muerte e invalidez $5.000 por ocupante.
               * Gastos médicos $1.500 por ocupante.
               * Gastos de grúa $300.
               * Ambulancia $300.
               """;
    }
    
    public String seguroPremium(){
        return """
               * Choque y/o volcadura.
               * Incendio y/o rayo.
               * Explosión.
               * Autoignición.
               * Caida de edificios, aeronaves o partes de estas.
               * Impacto de proyectiles.
               * Deslizamientos de tierra.
               * Fenómenos de la naturaleza.
               * Motín y huelgas.
               * Pérdidas totales o parciales por daños.
               * Robo y/o hurto total o parcial.
               * Rotura de vidrios.
               * Responsalibilidad vicil hasta un máximo de $20.000.
               * Muerte e invalidez para el titular de la póliza por $10.000.
               * Muerte e invalidez para cada ocupante por el valor de $4.000.
               * Gastos médicos $3.000 por ocupante.
               * Gastos de grúa $300.
               * Ambulancia $300.
               * Cobertura para airbag 100%.
               * Libre elección de taller.
               * Amparo patrimonial.
               * No depreciación en pérdidas parciales y totales.
               """;
    }
}
